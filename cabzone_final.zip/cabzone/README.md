# Cab Zone (final hackathon project)

Cabs are sent to crowded places (railway station, airport, stadium, any event) BEFORE the crowd arrives.
A circle (geofence) around each place turns red/orange/green/normal on the driver map depending on cab shortage.

## Run
    pip install -r requirements.txt
    uvicorn main:app --reload
Open http://127.0.0.1:8000 (internet needed for map tiles). API docs: /docs
If uvicorn is not found: python -m pip install fastapi "uvicorn[standard]" and python -m uvicorn main:app --reload

## The 5 steps and where they live
1. Demand zone (circle): `Zone` in engine.py; click the map + "Step 1" form, or "Create zone here" with live GPS
2. Estimate the crowd: seats x occupancy x share getting off (`Arrival.passengers()`); "Step 2" form
   LIVE UPDATE: real people count, delay or cancellation per arrival ("Step 2b"), timetable CSV upload, optional feeds (feeds.py)
3. Predict cab demand: crowd x cab share / group size (learned per hour from data/history.csv, history.py)
   LIVE LEARNING: after each arrival the system compares real bookings with what it expected and corrects the next forecast ("live factor")
4. Cab shortage: needed cabs (with a safety buffer) vs cabs inside the circle + on the way (`World.zone_state`)
5. Update continuously: `World.advance()` every minute; page refreshes every second

## Colours (area colour guide on the page)
| Condition | Indication |
|---|---|
| Demand much higher than supply | Red: High demand |
| Demand slightly higher than supply | Orange: Medium demand |
| Demand and supply balanced | Green: Balanced |
| Supply greater than demand | Normal: Low demand |
Only red/orange zones send alerts to drivers; "Go to zone" claims a slot so a zone cannot be flooded.

## Everything in the project
- Driver map + phone panel (alert, Go to zone), real GPS driver "ME" (Use my live location), Create zone here, Move demo drivers here
- Chatbot (bot.py): free, offline, answers from live zone data + history (zones needing cabs, why red, forecast, history, groups, live factor)
- History vs prediction table and people-per-cab split (estimated unless the CSV has a `party_size` column)
- Live crowd: timetable CSV upload (static/sample_timetable.csv), per-arrival actual count/delay/cancel, POST /api/zones/{id}/observe (real bookings -> live learning), live feeds, real-time clock

## Live feeds (optional, NOT tested by the author)
Set environment variables, tick "Real-time clock", press "Refresh live feeds":
    Windows PowerShell:  $env:AVIATIONSTACK_KEY="your_key"
    Mac/Linux:           export AVIATIONSTACK_KEY=your_key
- AVIATIONSTACK_KEY: flights for zones of kind "flight" (IATA_<ZONEID> sets the airport, default DEL)
- FEED_URL_<ZONEID>: any JSON URL returning [{"name","time":"HH:MM","seats","occupancy","share","delay","actual","cancelled"}]
Indian trains have no simple open API: use the timetable CSV or your own feed.

## 3-minute demo
1. Start: Station/Airport turn red, drivers head in, they turn green. Click a driver, press Go to zone.
2. Set "Actual crowd vs timetable" to 1.8x, Reset, run with "Live learning" ticked, then unticked, and compare served/missed.
3. Step 2b: enter 900 actual people for a train; need jumps immediately.
4. Ask the chatbot: "Why is the station red?", "How is live data changing demand?"

## Honest limits
- data/history.csv, the trains, flights and the match are SAMPLE data. Drivers are simulated (300).
- Live learning helps most when the fleet can cover real demand; with too few cabs no forecast creates cabs (the red zone then shows the shortage).
- API adapters are untested; the web server was not run by the author (engine/logic tested in plain Python).
