const $ = id => document.getElementById(id);
const COL = {red: "#d9392f", orange: "#e08a00", green: "#1f9d63", normal: "#5f7a99"};
const ORD = {red: 0, orange: 1, green: 2, normal: 3};
const LEGEND = [["red", "Demand is much higher than supply", "Red: High demand"], ["orange", "Demand is slightly higher than supply", "Orange: Medium demand"],
  ["green", "Demand and supply are balanced", "Green: Balanced"], ["normal", "Supply is greater than demand", "Normal: Low demand"]];
function renderLegend(s) {
  $("lg").innerHTML = "<tr><td></td><td><b>Condition</b></td><td><b>App indication</b></td><td></td></tr>" + LEGEND.map(([c, cond, ind]) => {
    const n = s.zones.filter(z => z.color === c).length;
    return `<tr class="${n ? "on" : ""}"><td><i style="background:${COL[c]}"></i></td><td>${cond}</td><td>${ind}</td><td class="n">${n} zone${n === 1 ? "" : "s"}</td></tr>`;
  }).join("");
}
const SC = {free: "#5b6577", enroute: "#e08a00", busy: "#b8bcc6"};
const map = L.map("map").setView([28.60, 77.19], 11);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {attribution: "© OpenStreetMap"}).addTo(map);
const zl = {}, dl = {}; let picked = null, pin = null, playing = null, selected = "D001", last = null, zoneOpts = "";

async function api(path, method = "GET", body) {
  const r = await fetch("/api" + path, {method, headers: {"Content-Type": "application/json"}, body: body ? JSON.stringify(body) : undefined});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.detail || r.statusText);
  return j;
}

function render(s) {
  last = s; $("clock").textContent = s.time;
  const ids = new Set(s.zones.map(z => z.id));
  Object.keys(zl).forEach(k => { if (!ids.has(k)) { map.removeLayer(zl[k]); delete zl[k]; } });
  s.zones.forEach(z => {
    if (!zl[z.id]) zl[z.id] = L.circle([z.lat, z.lng], {weight: 3, dashArray: "8 6"}).addTo(map).bindTooltip(z.name);
    zl[z.id].setRadius(z.radius_m).setStyle({color: COL[z.color], fillColor: COL[z.color], fillOpacity: z.color === "normal" ? 0.1 : 0.28});
  });
  s.drivers.forEach(d => {
    if (!dl[d.id]) { dl[d.id] = L.circleMarker([d.lat, d.lng], {radius: 4, weight: 1}).addTo(map); dl[d.id].on("click", () => { selected = d.id; $("drv").value = d.id; refreshAlert(); }); }
    dl[d.id].setLatLng([d.lat, d.lng]).setStyle({color: d.id === "ME" ? "#1a73e8" : SC[d.status], fillColor: d.id === "ME" ? "#1a73e8" : SC[d.status], fillOpacity: d.id === selected ? 1 : 0.8, radius: d.id === "ME" ? 9 : d.id === selected ? 7 : 4});
  });
  renderLegend(s);
  $("zones").innerHTML = [...s.zones].sort((a, b) => ORD[a.color] - ORD[b.color]).map(z => `<div class="zc ${z.color}"><b>${z.name}<span class="tag ${z.color}">${z.label}</span></b>
    <div class="hint">${z.message}</div><div class="steps">
    <span>Crowd due: <i>${z.crowd}</i></span><span>Cab share: <i>${Math.round(z.p_cab * 100)}%</i> · group <i>${z.group}</i></span>
    <span>Expected bookings: <i>${z.bookings}</i> <span class="hint">(timetable ${z.bookings_schedule})</span></span><span>Live factor: <i>${z.live_factor}x</i></span><span>Cabs needed: <i>${z.need}</i></span>
    <span>In zone / on the way: <i>${z.inside} / ${z.enroute}</i></span><span>Shortage (slots): <i>${z.gap}</i></span>
    <span>Served: <i>${z.served}</i></span><span>Missed: <i>${z.missed}</i>${z.fill_rate != null ? ` · fill ${Math.round(z.fill_rate * 100)}%` : ""}</span></div>
    ${z.upcoming.length ? `<div class="hint">Next: ${z.upcoming.slice(0, 3).map(u => `${u.time}${u.delay ? " +" + u.delay + "m" : ""} ${u.name} (${u.passengers}${u.live_count ? " live" : ""})`).join(" · ")}</div>` : ""}</div>`).join("");
  const opts = s.zones.map(z => `<option value="${z.id}">${z.name}</option>`).join("");
  if (opts !== zoneOpts) { const cur = $("az").value; $("az").innerHTML = opts; if (cur) $("az").value = cur; const cl = $("lz").value; $("lz").innerHTML = opts; if (cl) $("lz").value = cl; zoneOpts = opts; }
  fillArrivals();
  if ($("drv").options.length !== s.drivers.length) { $("drv").innerHTML = s.drivers.map(d => `<option>${d.id}</option>`).join(""); $("drv").value = selected; }
  $("log").innerHTML = s.log.slice().reverse().join("<br>") || "Nothing yet";
}

async function refreshAlert() {
  try {
    const a = await api(`/drivers/${selected}/alert`), box = $("alert"), go = $("go");
    if (a.alert) { box.className = "alert " + a.color; box.innerHTML = `<b>${a.name}</b><br>${a.slots_left} cabs needed · ${(a.distance_m / 1000).toFixed(1)} km away · about ${a.eta_min} min`; go.hidden = false; go.dataset.zone = a.zone; }
    else { box.className = "alert"; box.textContent = a.message; go.hidden = true; }
  } catch (e) { $("alert").textContent = e.message; }
}

async function tick(minutes) {
  try { render(await api(`/sim/advance?minutes=${minutes}&auto=${$("auto").checked}&live=${$("live").checked}`, "POST")); refreshAlert(); } catch (e) { $("msg").textContent = e.message; }
}

$("play").onclick = () => {
  if (playing) { clearInterval(playing); playing = null; $("play").textContent = "Start"; return; }
  $("play").textContent = "Pause"; playing = setInterval(() => tick(+$("speed").value), 1000);
};
$("step").onclick = () => tick(10);
$("reset").onclick = async () => { await api("/sim/reset", "POST"); await applyModes(); render(await api("/state")); refreshAlert(); };
$("drv").onchange = e => { selected = e.target.value; render(last); refreshAlert(); };
$("go").onclick = async () => {
  try { const r = await api(`/drivers/${selected}/accept/${$("go").dataset.zone}`, "POST"); $("msg").textContent = r.message; }
  catch (e) { $("msg").textContent = e.message; }
  render(await api("/state")); refreshAlert();
};
map.on("click", e => {
  picked = e.latlng; if (pin) map.removeLayer(pin); pin = L.marker(e.latlng).addTo(map);
  $("zloc").textContent = `Picked: ${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`;
});
$("zf").onsubmit = async e => {
  e.preventDefault();
  if (!picked) { $("zloc").textContent = "Click the map first"; return; }
  try {
    await api("/zones", "POST", {id: $("zid").value, name: $("znm").value, kind: $("zk").value, lat: picked.lat, lng: picked.lng, radius_m: +$("zr").value, p_cab: +$("zp").value});
    map.removeLayer(pin); pin = null; picked = null; $("zloc").textContent = "Zone created. Now add a crowd source below."; render(await api("/state"));
  } catch (err) { $("zloc").textContent = err.message; }
};
$("af").onsubmit = async e => {
  e.preventDefault();
  try { await api(`/zones/${$("az").value}/arrivals`, "POST", {name: $("an").value, time: $("at").value, seats: +$("as").value, occupancy: +$("ao").value, share: +$("ash").value}); render(await api("/state")); refreshAlert(); }
  catch (err) { $("log").textContent = err.message; }
};
(async () => { render(await api("/state")); refreshAlert(); })();

function addMsg(text, who) { const d = document.createElement("div"); d.className = "m " + who; d.textContent = text; $("chat").appendChild(d); $("chat").scrollTop = $("chat").scrollHeight; }
async function ask(text) {
  if (!text.trim()) return; addMsg(text, "u");
  try { const r = await api("/chat", "POST", {message: text, driver_id: selected}); addMsg(r.reply, "b"); }
  catch (e) { addMsg("Error: " + e.message, "b"); }
}
$("cf").onsubmit = e => { e.preventDefault(); const t = $("ci").value; $("ci").value = ""; ask(t); };
document.querySelectorAll(".chip").forEach(b => b.onclick = () => ask(b.textContent));
addMsg("Hi! I answer from the live zone data and the history file. Tap a suggestion or type a question.", "b");

// ---- live location: the browser GPS becomes a real driver called ME ----
let me = null, watchId = null, first = true;
function showMe(r) {
  if (!r.name) { $("me").textContent = "No zones yet."; return; }
  $("me").innerHTML = r.inside
    ? `<b>You are inside ${r.name}</b> (${r.label}). ` + (r.gap > 0 ? `${r.gap} more cabs needed here.` : "Enough cabs here.")
    : `You are outside all zones. Nearest: ${r.name}, ${(r.distance_m / 1000).toFixed(1)} km away (${r.label}).`;
}
async function pushMe() {
  if (!me) return;
  try {
    showMe(await api("/me/location", "POST", {lat: me.lat, lng: me.lng}));
    if (first) { first = false; selected = "ME"; map.setView([me.lat, me.lng], 13); $("mkz").hidden = false; $("mvd").hidden = false; }
    render(await api("/state")); refreshAlert();
  } catch (e) { $("me").textContent = e.message; }
}
$("loc").onclick = () => {
  if (!navigator.geolocation) { $("me").textContent = "This browser has no location support."; return; }
  if (watchId !== null) return;
  $("me").textContent = "Waiting for location permission…";
  watchId = navigator.geolocation.watchPosition(p => { me = {lat: p.coords.latitude, lng: p.coords.longitude}; },
    err => { $("me").textContent = "Location unavailable: " + err.message; navigator.geolocation.clearWatch(watchId); watchId = null; },
    {enableHighAccuracy: true});
  setInterval(pushMe, 4000);
};
$("mkz").onclick = async () => {
  if (!me) return;
  const name = prompt("Name of this zone?", "My zone"); if (!name) return;
  try { await api("/zones", "POST", {id: "Z" + Date.now().toString().slice(-5), name, kind: "event", lat: me.lat, lng: me.lng, radius_m: 300, p_cab: 0.1});
    $("log").textContent = "Zone created at your location. Add a crowd source in Step 2."; render(await api("/state")); }
  catch (e) { $("log").textContent = e.message; }
};
$("mvd").onclick = async () => { if (me) { render(await api("/sim/center", "POST", {lat: me.lat, lng: me.lng})); refreshAlert(); } };

// ---- history vs prediction + group sizes ----
async function loadAnalysis() {
  try {
    const a = await api("/analysis");
    if (!a.available) { $("an").textContent = "No history data loaded."; return; }
    const sh = a.group.share, colr = ["#5f7a99", "#1f9d63", "#e08a00", "#d9392f"], nm = ["1", "2", "3", "4+"];
    $("an").innerHTML = `<table class="an"><tr><th>Hour</th><th>Crowd</th><th>Predicted</th><th>Actual</th><th>Error</th></tr>` +
      a.compare.map(c => `<tr><td>${c.hour}:00</td><td>${c.crowd}</td><td>${c.predicted ?? "-"}</td><td>${c.actual} <span class="hint">(${c.actual_min}-${c.actual_max})</span></td><td>${c.error_pct == null ? "-" : (c.error_pct > 0 ? "+" : "") + c.error_pct + "%"}</td></tr>`).join("") +
      `</table><div class="hint">Predicted bookings use cab share learned from the other hours only. Average error: <b>${a.mape}%</b> (${a.zone}, ${a.days} days). Crowd comes from the sample timetable.</div>
      <h2 style="margin-top:10px">People per cab booking</h2><div class="bar">${sh.map((p, i) => `<span style="width:${p * 100}%;background:${colr[i]}">${p > 0.06 ? nm[i] + ": " + Math.round(p * 100) + "%" : ""}</span>`).join("")}</div>
      <div class="hint">Average ${a.group.mean} people per booking. ${a.group.source}.</div>`;
  } catch (e) { $("an").textContent = e.message; }
}
loadAnalysis(); $("reset").addEventListener("click", loadAnalysis);

// ---- live crowd updates, timetable upload, feeds, real-time clock ----
let arrOpts = "";
function fillArrivals() {
  const z = last && last.zones.find(x => x.id === $("lz").value); if (!z) return;
  const o = z.upcoming.map(u => `<option value="${u.idx}">${u.time} ${u.name}</option>`).join("");
  if (o !== arrOpts) { const cur = $("la").value; $("la").innerHTML = o; if (cur) $("la").value = cur; arrOpts = o; }
}
$("lz").onchange = () => { arrOpts = ""; fillArrivals(); };
$("lf").onsubmit = async e => {
  e.preventDefault();
  const body = {}; if ($("lp").value !== "") body.actual_passengers = +$("lp").value; if ($("ld").value !== "") body.delay_min = +$("ld").value;
  if (!$("la").value) { $("log").textContent = "No upcoming arrival to update."; return; }
  try { await api(`/zones/${$("lz").value}/arrivals/${$("la").value}`, "PUT", body); $("lp").value = ""; $("ld").value = ""; render(await api("/state")); refreshAlert(); }
  catch (err) { $("log").textContent = err.message; }
};
$("tf").onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  try { const r = await api(`/zones/${$("lz").value}/timetable`, "POST", {csv: await f.text()}); $("log").textContent = `Timetable loaded: ${r.loaded} arrivals.`; arrOpts = ""; render(await api("/state")); }
  catch (err) { $("log").textContent = err.message; }
  e.target.value = "";
};
$("fr").onclick = async () => { try { const r = await api("/feeds/refresh", "POST"); $("log").innerHTML = Object.entries(r).map(([k, v]) => `${k}: ${v}`).join("<br>"); render(await api("/state")); } catch (err) { $("log").textContent = err.message; } };
async function applyModes() {
  await api("/sim/mode", "POST", {realtime: $("rt").checked});
  const s = await api("/state");
  for (const z of s.zones) await api(`/zones/${z.id}`, "PUT", {truth: +$("truth").value});
}
$("rt").onchange = async () => { await applyModes(); render(await api("/state")); refreshAlert(); };
$("truth").onchange = async () => { await applyModes(); render(await api("/state")); };
