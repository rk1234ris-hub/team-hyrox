"""Step 3 helper: learn booking behaviour from the historical CSV."""
import csv, os

def load(path):
    if not os.path.exists(path):
        return {}
    by = {}
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            by.setdefault(int(r["hour"]), []).append(r)
    out = {}
    for h, rs in by.items():
        n = len(rs)
        req = sum(float(r["cab_booking_requests"]) for r in rs) / n
        pax = sum(float(r["estimated_passengers"]) for r in rs) / n
        done = sum(float(r["completed_bookings"]) for r in rs) / n
        out[h] = {"bookings": round(req, 1), "cab_passengers": round(pax, 1),
                  "group": round(pax / req, 2), "completion": round(done / req, 2)}
    return out

def calibrate(zone, hist):
    """Fill zone.group_by_hour and zone.p_by_hour (share of arriving crowd that books a cab)."""
    for h, v in hist.items():
        zone.group_by_hour[h] = v["group"]
        crowd = sum(a.passengers() for a in zone.arrivals if a.minute // 60 == h)
        if crowd > 0:
            zone.p_by_hour[h] = round(min(0.6, v["cab_passengers"] / crowd), 4)


# ---------- prediction vs history, and how many people share one cab ----------
import math


def load_rows(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _split_from_mean(mean, kmax=4):
    """Estimate share of bookings with 1,2,3,4+ people when only the AVERAGE party size is known
    (truncated Poisson on size-1, fitted so the mean matches). This is an estimate, not a measurement."""
    mean = min(max(mean, 1.01), kmax - 0.01)
    dist = lambda lam: [x / sum(lam ** i / math.factorial(i) for i in range(kmax))
                        for x in (lam ** i / math.factorial(i) for i in range(kmax))]
    m = lambda lam: sum((i + 1) * p for i, p in enumerate(dist(lam)))
    lo, hi = 0.0, 10.0
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if m(mid) < mean else (lo, mid)
    return [round(p, 3) for p in dist((lo + hi) / 2)]


def group_split(rows):
    """If the CSV has a per-booking 'party_size' column, count it exactly; otherwise estimate."""
    if rows and "party_size" in rows[0]:
        sizes = [int(float(r["party_size"])) for r in rows]
        n = len(sizes)
        d = [sum(1 for s in sizes if s == k) / n for k in (1, 2, 3)] + [sum(1 for s in sizes if s >= 4) / n]
        return {"share": [round(x, 3) for x in d], "mean": round(sum(sizes) / n, 2), "source": "actual bookings"}
    pax = sum(float(r["estimated_passengers"]) for r in rows)
    bk = sum(float(r["cab_booking_requests"]) for r in rows)
    mean = pax / bk
    return {"share": _split_from_mean(mean), "mean": round(mean, 2),
            "source": "estimated from the average group size (the CSV has no per-booking party size)"}


def analysis(zone, path):
    rows = load_rows(path)
    if not rows or zone is None:
        return {"available": False}
    by = {}
    for r in rows:
        by.setdefault(int(r["hour"]), []).append(r)
    st = {}
    for h, rs in by.items():
        bk = [float(r["cab_booking_requests"]) for r in rs]
        pax = [float(r["estimated_passengers"]) for r in rs]
        st[h] = {"bk": sum(bk) / len(bk), "pax": sum(pax) / len(pax), "lo": min(bk), "hi": max(bk),
                 "crowd": sum(a.passengers() for a in zone.arrivals if a.minute // 60 == h)}
    out, errs = [], []
    for h, s in sorted(st.items()):
        others = [o for k, o in st.items() if k != h and o["crowd"] > 0]
        pred = err = None
        if s["crowd"] > 0 and others:        # learn cab share + group size from the OTHER hours only
            p = sum(o["pax"] / o["crowd"] for o in others) / len(others)
            g = sum(o["pax"] / o["bk"] for o in others) / len(others)
            pred = s["crowd"] * p / g
            err = (pred - s["bk"]) / s["bk"] * 100
            errs.append(abs(err))
        out.append({"hour": h, "crowd": s["crowd"], "predicted": None if pred is None else round(pred, 1),
                    "actual": round(s["bk"], 1), "actual_min": s["lo"], "actual_max": s["hi"],
                    "error_pct": None if err is None else round(err, 1)})
    return {"available": True, "zone": zone.name, "days": len({r["date"] for r in rows}), "compare": out,
            "mape": round(sum(errs) / len(errs), 1) if errs else None, "group": group_split(rows),
            "group_by_hour": {h: group_split(rs) for h, rs in sorted(by.items())}}
