"""Optional LIVE feeds. NOT TESTED by the author: they need internet and your own API key.

Configure with environment variables, then press "Refresh live feeds" (or POST /api/feeds/refresh):
  AVIATIONSTACK_KEY=<your key>      flights for every zone of kind "flight" (airport code: IATA_<ZONEID>, default DEL)
  FEED_URL_<ZONEID>=<url>           any JSON URL returning [{"name","time":"HH:MM","seats","occupancy","share","delay","actual","cancelled"}]
Use together with the "Real-time clock" switch so zone times match the real clock.
"""
import json
import os
import urllib.parse
import urllib.request

from engine import Arrival, parse_hhmm


def _get_json(url, timeout=8):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.load(r)


def merge(zone, items):
    """Add new arrivals or update existing ones (matched by name)."""
    added = updated = 0
    for it in items:
        a = next((x for x in zone.arrivals if x.name.lower() == str(it["name"]).lower()), None)
        if a is None:
            share = float(it.get("share", 1.0 if zone.kind == "flight" else 0.5))
            a = Arrival(zone.kind, it["name"], parse_hhmm(it["time"]), int(it.get("seats", 180)),
                        float(it.get("occupancy", 0.85)), share)
            zone.arrivals.append(a)
            added += 1
        else:
            updated += 1
        if it.get("delay") is not None:
            a.delay = int(it["delay"])
        if it.get("actual") is not None:
            a.actual = int(it["actual"])
        if it.get("cancelled"):
            a.done = True
    return added, updated


def aviationstack(iata, key):
    """Arrivals at an airport. Field names follow AviationStack's documented format; check them against your plan."""
    url = "http://api.aviationstack.com/v1/flights?" + urllib.parse.urlencode(
        {"access_key": key, "arr_iata": iata, "limit": 100})
    out = []
    for f in _get_json(url).get("data", []):
        arr = f.get("arrival") or {}
        sched = arr.get("scheduled")
        if not sched:
            continue
        out.append({"name": (f.get("flight") or {}).get("iata") or "flight", "time": sched[11:16],
                    "delay": arr.get("delay") or 0, "cancelled": f.get("flight_status") == "cancelled"})
    return out


def refresh(world):
    status = {}
    for z in world.zones.values():
        try:
            url, key, items = os.getenv(f"FEED_URL_{z.id}"), os.getenv("AVIATIONSTACK_KEY"), None
            if url:
                items = _get_json(url)
            elif z.kind == "flight" and key:
                items = aviationstack(os.getenv(f"IATA_{z.id}", "DEL"), key)
            if items is None:
                status[z.id] = "no feed configured"
                continue
            items = [i for i in items if parse_hhmm(i["time"]) >= world.clock - 10]
            a, u = merge(z, items)
            status[z.id] = f"ok: {a} added, {u} updated"
        except Exception as e:
            status[z.id] = f"failed: {e}"
    return status
