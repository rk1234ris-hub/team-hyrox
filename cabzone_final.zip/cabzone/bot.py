"""Cab Zone assistant: answers questions from the live zone data and the history CSV.
Free and offline: simple intent matching, no API key needed."""
import re
from engine import hhmm

ALIASES = {"NDLS": ["station", "railway", "ndls", "train", "new delhi"],
           "IGI": ["airport", "igi", "flight", "t3"],
           "JLN": ["stadium", "jln", "match", "football", "nehru"]}


def find_zone(t, world):
    for zid, words in ALIASES.items():
        if zid in world.zones and any(w in t for w in words):
            return world.zones[zid]
    for z in world.zones.values():
        if re.search(r"\b" + re.escape(z.id.lower()) + r"\b", t) or \
           any(w in t for w in re.findall(r"[a-z]{4,}", z.name.lower())):
            return z
    return None


def forecast(world, z, minutes):
    arr = [a for a in z.arrivals if not a.done and a.at <= world.clock + minutes]
    return sum(z.bookings(a) for a in arr), len(arr)


def answer(world, hist, text, driver_id="D001", an=None):
    t = " " + text.lower().strip() + " "
    z = find_zone(t, world)
    S = {zz.id: world.zone_state(zz) for zz in world.zones.values()}
    has = lambda *w: any(x in t for x in w)
    line = lambda s: (f"{s['name']}: {s['label']} | need {s['need']} cabs, "
                      f"have {s['inside']} inside + {s['enroute']} on the way, shortage {s['gap']}")

    if has("compare", "accuracy", "accurate", "predicted vs", "actual", "back-test", "backtest"):
        if not an or not an.get("available"):
            return "No history data loaded."
        rows = "\n".join(f"{c['hour']}:00: crowd {c['crowd']}, predicted {c['predicted']} vs actual {c['actual']} bookings ({c['error_pct']:+.0f}%)"
                         for c in an["compare"] if c["predicted"] is not None)
        return (f"Predicted vs actual bookings ({an['zone']}, {an['days']} days of history), each hour predicted using cab share "
                f"learned from the other hours:\n{rows}\nAverage error: {an['mape']}%. The crowd comes from the sample timetable, "
                "so this checks the pipeline; real timetables are needed for a real accuracy figure.")

    if has("group", "per cab", "people per", "share a cab", "solo", "alone", "split", "3 people", "2 people", "three people"):
        if not an or not an.get("available"):
            return "No history data loaded."
        g = an["group"]; s = g["share"]
        msg = (f"Average group size is {g['mean']} people per booking. Of 100 bookings: about {round(s[0] * 100)} are 1 person, "
               f"{round(s[1] * 100)} are 2 people, {round(s[2] * 100)} are 3 people, {round(s[3] * 100)} are 4 or more. "
               f"Source: {g['source']}.")
        if z:
            b, _ = forecast(world, z, 60)
            msg += (f"\nFor {z.name} in the next hour (~{round(b)} bookings): about {round(b * s[0])} solo, {round(b * s[1])} pairs, "
                    f"{round(b * s[2])} groups of 3, {round(b * s[3])} of 4+.")
        return msg

    if has("where am i", "my location", "which area am i", "am i in", "my area"):
        d = world.drivers.get("ME")
        if not d:
            return "Press 'Use my live location' in the Driver phone panel first."
        r = world.locate(d.lat, d.lng)
        if r["inside"]:
            return (f"You are inside the {r['name']} zone ({r['label']}). "
                    + (f"{r['gap']} more cabs are needed here." if r["gap"] > 0 else "There are enough cabs here."))
        return f"You are outside all zones. Nearest: {r['name']}, {r['distance_m'] / 1000:.1f} km away ({r['label']})."

    if has("live", "real data", "real-time", "realtime", "adjust", "factor", "busier", "quieter"):
        lines = "\n".join(f"{s['name']}: timetable ~{s['bookings_schedule']} bookings, live-adjusted ~{s['bookings']} (live factor {s['live_factor']}x)"
                          for s in S.values())
        return (lines + "\nA factor above 1 means more people are booking than the timetable suggests, so the system asks for more cabs; "
                "below 1 means fewer. It also uses real counts (tickets scanned, event manager), delays and cancellations you send, and live feeds when configured.")

    if has("how does", "how it work", "how do you", "method", "explain the system"):
        return ("The system works in 5 steps: (1) a circle (geofence) is drawn around the place, "
                "(2) crowd = seats x occupancy x share getting off, (3) crowd x cab share / group size = expected bookings "
                "(cab share and group size are learned from the history data), (4) cabs needed is compared with cabs inside "
                "and on the way, (5) it is recalculated every minute. Red = high demand, orange = medium demand, green = balanced, normal = low demand (supply is greater than demand).")

    if has("why") and z:
        s = S[z.id]
        return (f"{z.name} is marked {s['label']} because: crowd due in the next {z.horizon} min = {s['crowd']} people; "
                f"about {round(s['p_cab'] * 100)}% book a cab in groups of {s['group']}, so ~{s['bookings']} bookings; "
                f"the timetable alone says ~{s['bookings_schedule']} but live data adjusts it by {s['live_factor']}x, giving ~{s['bookings']}; with a safety buffer we need {s['need']} cabs. Supply is {s['inside']} inside + {s['enroute']} on the way, "
                f"so the shortage is {s['gap']}.")

    if has("where should", "where do i go", "where to go", "best zone", "my alert", "driver"):
        a = world.alert(driver_id)
        if not a:
            return "I can't find that driver."
        if not a["alert"]:
            return f"Driver {driver_id}: {a['message']}."
        return (f"Driver {driver_id}: go to {a['name']} ({a['label']}). {a['slots_left']} cabs still needed, "
                f"{a['distance_m'] / 1000:.1f} km away, about {a['eta_min']} min.")

    if has("forecast", "next hour", "predict", "will ", "coming"):
        zs = [z] if z else list(world.zones.values())
        out = []
        for zz in zs:
            b, n = forecast(world, zz, 60)
            out.append(f"{zz.name}: {n} arrival(s) in the next hour, about {round(b)} expected bookings")
        return "Forecast for the next 60 minutes:\n" + "\n".join(out)

    if has("red", "shortage", "short of", "which zone", "need cabs", "hotspot", "busy now"):
        bad = sorted((s for s in S.values() if s["gap"] > 0), key=lambda s: -s["gap"])
        if not bad:
            return "No zone has a shortage right now. Every zone is balanced or low demand."
        return "Zones needing cabs now:\n" + "\n".join(line(s) for s in bad)

    if has("how many cab", "cabs needed", "need", "required") and z:
        return line(S[z.id])

    if has("next", "schedule", "arrival", "upcoming", "when") and z:
        up = S[z.id]["upcoming"]
        if not up:
            return f"No upcoming arrivals recorded for {z.name}."
        return f"Next at {z.name}:\n" + "\n".join(
            f"{u['time']} {u['name']}: {u['passengers']} people, ~{u['bookings']} bookings" for u in up[:5])

    if has("history", "peak", "busiest", "pattern", "past", "average"):
        if not hist:
            return "No history data loaded."
        peak = max(hist, key=lambda h: hist[h]["bookings"])
        rows = "\n".join(f"{h}:00-{h + 1}:00: ~{v['bookings']} bookings, group size {v['group']}, "
                         f"{round(v['completion'] * 100)}% completed" for h, v in sorted(hist.items()))
        return f"From the history data (synthetic demo): busiest hour is {peak}:00.\n{rows}"

    if has("served", "missed", "fill", "performance", "result", "score"):
        return "\n".join(f"{s['name']}: served {s['served']}, missed {s['missed']}"
                         + (f", fill rate {round(s['fill_rate'] * 100)}%" if s["fill_rate"] is not None else "")
                         for s in S.values())

    if z:
        return line(S[z.id])

    if re.search(r"\b(hi|hello|hey|help)\b", t) or has("what can you"):
        return ("Hi! Ask me things like: Which zones need cabs? | Why is the station red? | "
                "How many cabs does the airport need? | Next arrivals at the stadium | "
                "Forecast for the next hour | Where should my driver go? | What is the busiest hour?")

    return ("I didn't get that. Try: 'Which zones need cabs?', 'Why is the station red?', "
            "'Forecast next hour', 'Where should driver go?' or 'Busiest hour?'")
