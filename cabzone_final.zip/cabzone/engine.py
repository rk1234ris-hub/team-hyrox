"""Cab Zone engine: the 5 steps (zone -> crowd -> cab demand -> shortage -> continuous update)."""
import csv, io, math, random
from dataclasses import dataclass, field

def haversine_m(a1, o1, a2, o2):
    p1, p2 = math.radians(a1), math.radians(a2)
    dp, dl = p2 - p1, math.radians(o2 - o1)
    x = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * 6371000 * math.asin(math.sqrt(x))

LABELS = {"red": "High demand", "orange": "Medium demand", "green": "Balanced", "normal": "Low demand"}

def hhmm(m):
    return f"{int(m) // 60:02d}:{int(m) % 60:02d}"

def parse_hhmm(s):
    h, m = s.split(":")
    return int(h) * 60 + int(m)

@dataclass
class Arrival:                      # a train, a flight or an event ending
    kind: str
    name: str
    minute: int
    seats: int
    occupancy: float
    share: float                    # share of people who arrive/leave here
    done: bool = False
    delay: int = 0                  # minutes late (live feed or manual update)
    actual: int | None = None       # REAL passenger count if known (ticket scans, feed, event manager)
    @property
    def at(self):                   # real expected arrival minute
        return self.minute + self.delay
    def passengers(self):
        return self.actual if self.actual is not None else round(self.seats * self.occupancy * self.share)

@dataclass
class Driver:
    id: str
    lat: float
    lng: float
    status: str = "free"            # free | enroute | busy
    zone: str = ""                  # target zone while enroute
    eta: float = 0
    live: bool = False              # a real phone (GPS), not a simulated driver

@dataclass
class Zone:                         # Step 1: a demand zone = centre + radius (the geofence)
    id: str
    name: str
    kind: str
    lat: float
    lng: float
    radius_m: int = 300
    p_cab: float = 0.06             # default share of crowd that books a cab
    group: float = 1.5
    per_cab: float = 1.0
    horizon: int = 30
    arrivals: list = field(default_factory=list)
    p_by_hour: dict = field(default_factory=dict)
    group_by_hour: dict = field(default_factory=dict)
    served: int = 0
    missed: int = 0
    live_factor: float = 1.0        # learned: how much busier/quieter than the timetable model today really is
    truth: float = 1.0              # SIMULATION ONLY: hidden real crowd vs timetable (used to test the live learning)
    def p(self, h): return self.p_by_hour.get(h, self.p_cab)
    def g(self, h): return self.group_by_hour.get(h, self.group)
    def base_bookings(self, a):     # Step 3: timetable/crowd x cab share / group size
        h = a.at // 60
        return a.passengers() * self.p(h) / self.g(h)
    def bookings(self, a):          # ... corrected by what live data has shown so far today
        return self.base_bookings(a) * self.live_factor
    def learn(self, expected, actual):
        """Live correction: compare real bookings with what the model expected, nudge the factor."""
        if expected >= 3:
            self.live_factor = min(3.0, max(0.4, 0.5 * self.live_factor + 0.5 * actual / expected))

class World:
    def __init__(self, seed=7):
        self.rng = random.Random(seed)
        self.clock = 14 * 60
        self.zones, self.drivers, self.log = {}, {}, []
        self.live_on, self.realtime = True, False
        self.center = (28.62, 77.20)

    # ---------- geometry / supply ----------
    def dist(self, d, z): return haversine_m(d.lat, d.lng, z.lat, z.lng)
    def inside(self, z):
        return [d for d in self.drivers.values() if d.status == "free" and self.dist(d, z) <= z.radius_m]
    def enroute(self, z):
        return [d for d in self.drivers.values() if d.status == "enroute" and d.zone == z.id]
    def _point(self, lat, lng, min_m, max_m):
        a = self.rng.uniform(0, 6.2832)
        r = math.sqrt(self.rng.uniform(min_m ** 2, max_m ** 2))
        return lat + r * math.sin(a) / 111320, lng + r * math.cos(a) / (111320 * math.cos(math.radians(lat)))
    def seed_drivers(self, n=300):
        self.drivers.clear()
        for i in range(n):
            lat, lng = self._point(*self.center, 0, 9000)
            self.drivers[f"D{i + 1:03d}"] = Driver(f"D{i + 1:03d}", lat, lng)

    # ---------- Steps 2-4 ----------
    def zone_state(self, z):
        win = [a for a in z.arrivals if not a.done and a.at <= self.clock + z.horizon]
        crowd = sum(a.passengers() for a in win)                       # Step 2
        b = sum(z.bookings(a) for a in win)                            # Step 3
        need = math.ceil((b + 1.28 * math.sqrt(b)) / z.per_cab) if b else 0   # safety buffer
        ins, en = len(self.inside(z)), len(self.enroute(z))
        gap = max(0, need - ins - en)                                  # Step 4
        supply = ins + en
        if need == 0: color, msg = "normal", "Low demand: no crowd due"
        elif gap >= max(4, need * 0.4): color, msg = "red", "High demand: demand is much higher than supply"
        elif gap > 0: color, msg = "orange", "Medium demand: demand is slightly higher than supply"
        elif supply > need * 1.25: color, msg = "normal", "Low demand: supply is greater than demand"
        else: color, msg = "green", "Balanced: demand and supply match"
        tot = z.served + z.missed
        h = int(self.clock) // 60
        return {"id": z.id, "name": z.name, "kind": z.kind, "lat": z.lat, "lng": z.lng,
                "radius_m": z.radius_m, "color": color, "label": LABELS[color], "message": msg,
                "crowd": crowd, "p_cab": z.p(h), "group": z.g(h), "bookings": round(b, 1),
                "live_factor": round(z.live_factor, 2), "bookings_schedule": round(sum(z.base_bookings(a) for a in win), 1),
                "truth": z.truth, "need": need, "inside": ins, "enroute": en, "gap": gap,
                "served": z.served, "missed": z.missed, "fill_rate": round(z.served / tot, 2) if tot else None,
                "upcoming": [{"idx": i, "name": a.name, "time": hhmm(a.at), "kind": a.kind, "delay": a.delay,
                              "live_count": a.actual is not None, "passengers": a.passengers(),
                              "bookings": round(z.bookings(a), 1)}
                             for i, a in sorted(enumerate(z.arrivals), key=lambda t: t[1].at) if not a.done][:6]}

    def snapshot(self):
        return {"time": hhmm(self.clock),
                "zones": [self.zone_state(z) for z in self.zones.values()],
                "drivers": [{"id": d.id, "lat": d.lat, "lng": d.lng, "status": d.status, "zone": d.zone}
                            for d in self.drivers.values()], "log": self.log[-8:]}

    # ---------- live location ----------
    def locate(self, lat, lng):
        """Which zone is this GPS point in (or nearest to)?"""
        best = None
        for z in self.zones.values():
            dm = haversine_m(lat, lng, z.lat, z.lng)
            if best is None or dm < best[0]:
                best = (dm, z)
        if not best:
            return {"inside": False, "name": None}
        dm, z = best
        s = self.zone_state(z)
        return {"inside": dm <= z.radius_m, "zone": z.id, "name": z.name, "distance_m": round(dm),
                "color": s["color"], "label": s["label"], "gap": s["gap"], "need": s["need"], "message": s["message"]}

    def upsert_live(self, lat, lng, did="ME"):
        d = self.drivers.get(did)
        if d is None:
            d = self.drivers[did] = Driver(did, lat, lng, live=True)
        d.lat, d.lng = lat, lng
        return d

    def set_center(self, lat, lng):
        """Move the demo drivers around a new area (e.g. where you really are)."""
        live = {k: v for k, v in self.drivers.items() if v.live}
        self.center = (lat, lng)
        self.seed_drivers(300)
        self.drivers.update(live)

    # ---------- live crowd inputs ----------
    def update_arrival(self, zid, idx, actual=None, delay=None, cancelled=False):
        a = self.zones[zid].arrivals[idx]
        if cancelled:
            a.done = True
            return
        if actual is not None:
            a.actual = max(0, int(actual))
        if delay is not None:
            a.delay = int(delay)

    def load_timetable(self, zid, text):
        z = self.zones[zid]
        z.arrivals = [Arrival(z.kind, r["name"], parse_hhmm(r["time"]), int(float(r["seats"])),
                              float(r.get("occupancy") or 0.85), float(r.get("share") or 0.5))
                      for r in csv.DictReader(io.StringIO(text))]
        return len(z.arrivals)

    def set_realtime(self, on):
        """Follow the real wall clock (use with real feeds). Arrivals already in the past are skipped."""
        import datetime
        self.realtime = on
        if on:
            n = datetime.datetime.now()
            self.clock = n.hour * 60 + n.minute
            for z in self.zones.values():
                for a in z.arrivals:
                    if a.at < self.clock:
                        a.done = True

    def sync_realtime(self, auto=True):
        import datetime
        n = datetime.datetime.now(); m = n.hour * 60 + n.minute
        if m > self.clock:
            self.advance(min(m - self.clock, 30), auto)
        self.clock = max(self.clock, m)

    # ---------- driver actions ----------
    def alert(self, driver_id):
        d = self.drivers.get(driver_id)
        if not d: return None
        if d.status != "free": return {"alert": False, "message": f"You are {d.status}"}
        best = None
        for z in self.zones.values():
            s = self.zone_state(z)
            if s["gap"] > 0 and (best is None or self.dist(d, z) < best[0]):
                best = (self.dist(d, z), z, s)
        if not best: return {"alert": False, "message": "No shortage zones right now"}
        dm, z, s = best
        return {"alert": True, "zone": z.id, "name": z.name, "color": s["color"], "label": s["label"], "slots_left": s["gap"],
                "distance_m": round(dm), "eta_min": max(1, round(dm / 500))}

    def accept(self, driver_id, zone_id):
        d, z = self.drivers.get(driver_id), self.zones.get(zone_id)
        if not d or not z or d.status != "free": return False, "Driver unavailable"
        if self.zone_state(z)["gap"] <= 0: return False, "Zone already has enough cabs"
        d.status, d.zone = "enroute", z.id
        d.eta = self.clock + max(1, self.dist(d, z) / 500)            # about 30 km/h
        return True, f"Go to {z.name}. Arrive about {hhmm(d.eta)}"

    # ---------- Step 5: keep recalculating ----------
    def advance(self, minutes=1, auto=True):
        for _ in range(int(minutes)):
            self.clock += 1
            for d in self.drivers.values():
                if d.live:           # real driver: position comes from GPS, never teleported
                    zz = self.zones.get(d.zone)
                    if d.status == "enroute" and (zz is None or self.dist(d, zz) <= zz.radius_m):
                        d.status, d.zone = "free", ""
                    continue
                if d.status in ("enroute", "busy") and self.clock >= d.eta:
                    if d.status == "enroute":
                        z = self.zones[d.zone]; d.lat, d.lng = self._point(z.lat, z.lng, 0, z.radius_m * 0.7)
                    else:
                        d.lat, d.lng = self._point(*self.center, 0, 9000)
                    d.status, d.zone = "free", ""
            for z in self.zones.values():
                for a in z.arrivals:
                    if not a.done and self.clock >= a.at:
                        a.done = True
                        exp = z.base_bookings(a)
                        n = round(exp * z.truth * self.rng.uniform(0.85, 1.15))   # what really happens
                        for _ in range(n):
                            free = sorted((x for x in self.inside(z) if not x.live), key=lambda d: self.dist(d, z))
                            if free:
                                free[0].status, free[0].eta = "busy", self.clock + self.rng.randint(18, 35)
                                z.served += 1
                            else:
                                z.missed += 1
                        if self.live_on:
                            z.learn(exp, n)
                        self.log.append(f"{hhmm(self.clock)} {z.name}: {a.name} ({n} bookings, live factor {z.live_factor:.2f}x)")
            if auto:                 # simulated drivers accept the most urgent red zones
                def urgency(z):      # serve the zone whose crowd arrives soonest first
                    t = [a.at for a in z.arrivals if not a.done and a.at <= self.clock + z.horizon]
                    return min(t) if t else 10 ** 6
                for z in sorted(self.zones.values(), key=urgency):
                    gap = self.zone_state(z)["gap"]
                    cand = sorted((d for d in self.drivers.values() if d.status == "free" and not d.live
                                   and self.dist(d, z) > z.radius_m), key=lambda d: self.dist(d, z))[:gap]
                    for d in cand: self.accept(d.id, z.id)

def build_world():
    from history import load, calibrate
    import os
    w = World()
    A = Arrival
    ndls = Zone("NDLS", "New Delhi Railway Station", "train", 28.6430, 77.2197, 300, 0.05, 1.5)
    ndls.arrivals = [A("train", n, m, s, o, sh) for n, m, s, o, sh in [
        ("12301 Rajdhani", 850, 1100, .85, .5), ("12002 Shatabdi", 865, 1000, .8, .45),
        ("12951 Mumbai Rajdhani", 890, 1100, .85, .55), ("12432 Trivandrum Exp", 915, 1200, .8, .4),
        ("12723 Telangana Exp", 940, 1300, .85, .45), ("12615 Grand Trunk", 962, 1300, .85, .5),
        ("12801 Purushottam Exp", 985, 1300, .9, .5), ("12265 Duronto", 1000, 1100, .85, .55)]]
    calibrate(ndls, load(os.path.join(os.path.dirname(__file__), "data", "history.csv")))
    igi = Zone("IGI", "Delhi Airport T3", "flight", 28.5562, 77.1000, 400, 0.25, 1.6)
    igi.arrivals = [A("flight", n, m, 180, .85, 1.0) for n, m in [("AI 802", 860), ("6E 2041", 905), ("UK 996", 945), ("SG 8194", 990), ("AI 101", 1020)]]
    stad = Zone("JLN", "Jawaharlal Nehru Stadium", "event", 28.5828, 77.2338, 350, 0.12, 1.8)
    stad.arrivals = [A("event", "Football match ends", 990, 1500, 0.9, 1.0)]
    for z in (ndls, igi, stad): w.zones[z.id] = z
    w.seed_drivers(300)
    return w
