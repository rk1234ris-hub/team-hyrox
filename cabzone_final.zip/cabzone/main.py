"""Cab Zone server.  Run:  uvicorn main:app --reload   then open http://127.0.0.1:8000"""
import os
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from engine import Zone, Arrival, build_world, parse_hhmm
from history import load, analysis
from feeds import refresh
from bot import answer

HERE = os.path.dirname(os.path.abspath(__file__))
app = FastAPI(title="Cab Zone API")
world = build_world()
CSV = os.path.join(HERE, "data", "history.csv")


def pick_zone():
    return world.zones.get("NDLS") or next(iter(world.zones.values()), None)


class ZoneIn(BaseModel):
    id: str
    name: str
    kind: str = "event"          # train | flight | event
    lat: float
    lng: float
    radius_m: int = 300
    p_cab: float = 0.1
    group: float = 1.6


class ArrivalIn(BaseModel):
    name: str
    time: str                    # "16:30"
    seats: int
    occupancy: float = 0.85
    share: float = 0.5


class ZoneSettings(BaseModel):
    radius_m: int | None = None
    p_cab: float | None = None
    group: float | None = None
    horizon: int | None = None
    truth: float | None = None      # simulation only


class ArrivalUpdate(BaseModel):
    actual_passengers: int | None = None
    delay_min: int | None = None
    cancelled: bool = False


class Timetable(BaseModel):
    csv: str                     # columns: name,time,seats,occupancy,share


class Observe(BaseModel):
    actual_bookings: int         # real cab requests that came for the latest arrival
    expected_bookings: float | None = None


class Mode(BaseModel):
    realtime: bool


class Chat(BaseModel):
    message: str
    driver_id: str = "D001"


class Loc(BaseModel):
    lat: float
    lng: float


def zone_or_404(zid):
    z = world.zones.get(zid)
    if not z:
        raise HTTPException(404, "Unknown zone")
    return z


@app.get("/api/state")
def state():
    return world.snapshot()


@app.post("/api/zones")                                   # Step 1: create a geofence
def create_zone(z: ZoneIn):
    zid = z.id.upper()
    world.zones[zid] = Zone(zid, z.name, z.kind, z.lat, z.lng, z.radius_m, z.p_cab, z.group)
    return world.zone_state(world.zones[zid])


@app.post("/api/zones/{zid}/arrivals")                    # Step 2: crowd source (timetable / event manager)
def add_arrival(zid: str, a: ArrivalIn):
    z = zone_or_404(zid)
    z.arrivals.append(Arrival(z.kind, a.name, parse_hhmm(a.time), a.seats, a.occupancy, a.share))
    return world.zone_state(z)


@app.put("/api/zones/{zid}")
def tune(zid: str, s: ZoneSettings):
    z = zone_or_404(zid)
    for k, v in s.model_dump().items():
        if v is not None:
            setattr(z, k, v)
    return world.zone_state(z)


@app.delete("/api/zones/{zid}")
def delete_zone(zid: str):
    zone_or_404(zid)
    del world.zones[zid]
    return {"deleted": zid}


@app.get("/api/history")                                  # Step 3: what we learned from past bookings
def history():
    return load(os.path.join(HERE, "data", "history.csv"))


@app.get("/api/analysis")                                 # predicted vs actual bookings + group-size split
def analysis_ep():
    return analysis(pick_zone(), CSV)


@app.post("/api/drivers/{did}/location")
def location(did: str, loc: Loc):
    d = world.drivers.get(did)
    if not d:
        raise HTTPException(404, "Unknown driver")
    if d.status != "enroute":
        d.lat, d.lng = loc.lat, loc.lng
    return {"ok": True}


@app.get("/api/drivers/{did}/alert")
def alert(did: str):
    a = world.alert(did)
    if a is None:
        raise HTTPException(404, "Unknown driver")
    return a


@app.post("/api/drivers/{did}/accept/{zid}")
def accept(did: str, zid: str):
    ok, msg = world.accept(did, zid)
    if not ok:
        raise HTTPException(409, msg)
    return {"accepted": True, "message": msg}


@app.post("/api/sim/advance")                             # Step 5: recalculate as time moves
def advance(minutes: int = 1, auto: bool = True, live: bool = True):
    world.live_on = live
    if world.realtime:
        world.sync_realtime(auto)
    else:
        world.advance(minutes, auto)
    return world.snapshot()


@app.post("/api/sim/mode")                                # follow the real clock (for real feeds)
def sim_mode(m: Mode):
    world.set_realtime(m.realtime)
    return world.snapshot()


@app.put("/api/zones/{zid}/arrivals/{idx}")               # live update: real people count, delay, cancellation
def update_arrival(zid: str, idx: int, u: ArrivalUpdate):
    zone_or_404(zid)
    try:
        world.update_arrival(zid, idx, u.actual_passengers, u.delay_min, u.cancelled)
    except IndexError:
        raise HTTPException(404, "Unknown arrival")
    return world.zone_state(world.zones[zid])


@app.post("/api/zones/{zid}/timetable")                   # load a real timetable (CSV text)
def timetable(zid: str, t: Timetable):
    zone_or_404(zid)
    try:
        n = world.load_timetable(zid, t.csv)
    except (KeyError, ValueError) as e:
        raise HTTPException(400, f"Bad CSV ({e}). Columns needed: name,time,seats,occupancy,share")
    return {"loaded": n}


@app.post("/api/zones/{zid}/observe")                     # real bookings seen by your booking system -> live learning
def observe(zid: str, o: Observe):
    z = zone_or_404(zid)
    exp = o.expected_bookings if o.expected_bookings is not None else world.zone_state(z)["bookings_schedule"]
    z.learn(exp, o.actual_bookings)
    return world.zone_state(z)


@app.post("/api/feeds/refresh")                           # pull flight/train feeds if configured
def feeds_refresh():
    return refresh(world)


@app.post("/api/sim/reset")
def reset():
    global world
    world = build_world()
    return world.snapshot()


@app.post("/api/chat")                                    # assistant bot (free, uses live data + history)
def chat(c: Chat):
    hist = load(os.path.join(HERE, "data", "history.csv"))
    return {"reply": answer(world, hist, c.message, c.driver_id, analysis(pick_zone(), CSV))}


@app.post("/api/me/location")                             # real GPS from the browser
def me_location(loc: Loc):
    world.upsert_live(loc.lat, loc.lng)
    return world.locate(loc.lat, loc.lng)


@app.post("/api/sim/center")                              # put demo drivers around a real place
def sim_center(loc: Loc):
    world.set_center(loc.lat, loc.lng)
    return world.snapshot()


app.mount("/static", StaticFiles(directory=os.path.join(HERE, "static")), name="static")


@app.get("/")
def index():
    return FileResponse(os.path.join(HERE, "static", "index.html"))
